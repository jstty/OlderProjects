//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Alien Mansion.rc
//
#define IDS_TITLE                       1
#define IDS_REPLACE                     2
#define IDST_REPLACE                    2
#define IDUSE                           50
#define IDEXAMINE                       51
#define IDCLEAR                         52
#define IDOPEN                          53
#define IDHELPBUTTON                    54
#define IDTALK                          55
#define IDDEL                           56
#define IDGIVE                          56
#define IDGET                           57
#define IDBCLOSE                        58
#define IDPUSHPULL                      59
#define IDI_ICON                        101
#define IDR_CONTROLS                    104
#define IDR_FILEUTILS                   105
#define IDD_SAVEFILE                    108
#define IDD_LOADFILE                    109
#define IDD_CONTROLBARS                 110
#define IDD_CONTROLBARL                 111
#define IDD_TEXTS                       112
#define IDD_TEXTL                       113
#define IDD_OPTIONS                     115
#define IDI_STAKE                       118
#define IDI_ROBOARM                     119
#define IDI_KEY                         120
#define IDI_VEGGY                       121
#define IDI_CANDYBAR                    122
#define IDI_SODA                        123
#define IDI_SANTA                       124
#define IDI_APP                         125
#define IDI_STAMP                       126
#define IDI_REMOTE                      127
#define IDI_ENVELOP1                    128
#define IDI_ENVELOP2                    129
#define IDI_ENVELOP3                    130
#define IDI_ENVELOP4                    131
#define IDB_LOAD1                       133
#define IDB_LOAD2                       134
#define IDB_EXIT1                       136
#define IDB_EXIT2                       137
#define IDB_NEW1                        138
#define IDB_NEW2                        139
#define IDD_CDPLAYER                    140
#define IDR_OPTIONS                     145
#define IDB_BITMAP                      202
#define IDB_BITMAP1                     203
#define IDB_BITMAP2                     204
#define IDB_BITMAP3                     205
#define IDB_BITMAPM                     206
#define IDC_STATICNAME                  1000
#define IDOPTION                        1000
#define IDC_NAME                        1001
#define IDEXIT                          1004
#define IDHELPTXT                       1006
#define IDC_TABBAR                      1007
#define IDMIDISND                       1009
#define IDC_EDIT1                       1011
#define IDC_EDIT2                       1012
#define IDC_LIST                        1013
#define IDWAVSND                        1013
#define IDC_PLAYLIST2                   1013
#define IDCDSND                         1014
#define IDC_PLAYLIST                    1015
#define IDC_ITEMLIST                    1016
#define IDC_TRACK                       1024
#define IDC_TEXTBAR                     1025
#define IDC_TIME                        1025
#define IDC_S_TRACK                     1026
#define IDC_S_TIME                      1027
#define IDC_EDIT_PL                     1032
#define IDC_EDIT_PL2                    1033
#define IDC_CD_RW2                      1034
#define IDC_CD_PLAY2                    1035
#define IDC_CD_STOP2                    1036
#define IDC_CD_FF2                      1037
#define IDC_CD_EJECT2                   1038
#define IDC_CD_PAUSE2                   1039
#define IDC_CD_RW                       1040
#define IDC_CD_PLAY                     1041
#define IDC_SHUF_PL2                    1041
#define IDC_CD_FF                       1042
#define IDC_CD_PAUSE                    1043
#define IDC_CD_STOP                     1044
#define IDC_TEXTBOX                     1045
#define IDC_CD_EJECT                    1045
#define IDC_SHUF                        1046
#define IDC_RDISK2                      1051
#define IDC_RTRACK2                     1052
#define IDC_RDISK                       1053
#define IDC_RTRACK                      1054
#define IDLEFT                          40001
#define IDRIGHT                         40002
#define IDUP                            40003
#define IDDOWN                          40004
#define IDLOAD                          40005
#define IDSAVE                          40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1055
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
