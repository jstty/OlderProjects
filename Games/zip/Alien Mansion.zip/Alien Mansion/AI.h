////////////////////////////////////////////////////////////////////////
//	Program Name:	Artificial Intelligence.h
//	Programmer:		Joseph Sutton
//	Company:			Moggie Software
//	Corporation:	Willy Wong Ping Pong Inc.
//	Description:	Artificial Intelligence header File
//	Date: 
////////////////////////////////////////////////////////////////////////

int RandomNum(int iRanMax);

void RandomList(int *iRanArray, int iListMax, int iRanMax);

void ArrayCopy(float *Des, float *Src, unsigned int num);