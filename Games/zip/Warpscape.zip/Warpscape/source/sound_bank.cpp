/****************************************
 filename:    sound_bank.cpp
 project:     warpattack
 created by:  Joseph E. Sutton
 date:        2010/04/07
 description: 
 ****************************************/
#include "global.h"

cSoundBank::cSoundBank()
{
   // TODO
}

cSoundBank::~cSoundBank()
{
   // TODO
}

void cSoundBank::Play(const char *name)
{
   // TODO
}

void cSoundBank::Pause(const char *name)
{
   // TODO
}

void cSoundBank::Stop(const char *name)
{
   // TODO
}

void cSoundBank::AddWave(const char *name, const char *filename)
{
   // TODO
}

void cSoundBank::AddMidi(const char *name, const char *filename)
{
   // TODO
}


int cSoundBank::Load(const char *filename)
{
   // TODO
   
   return 0;
}