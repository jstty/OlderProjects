/****************************************
 filename:    background.h
 project:     warpattack
 created by:  Joseph E. Sutton
 date:        2010/04/08
 description: background interface
 ****************************************/
#ifndef _BACKGROUND_
#define _BACKGROUND_

class cBackground
{
public:
   virtual void Draw() {}
   virtual void Update() {}

protected:
   
   
};

#endif // _BACKGROUND_
