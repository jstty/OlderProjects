//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Levels.rc
//
#define IDS_P1                          108
#define IDS_P1M                         109
#define IDS_P2                          120
#define IDS_P2M                         121
#define IDS_COM                         122
#define IDW_END1                        123
#define IDW_END2A                       124
#define IDW_END2B                       125
#define IDW_HIT1                        126
#define IDW_HIT2                        127
#define IDW_HIT3                        128
#define IDW_TITLE1                      129
#define IDW_TITLE2                      130
#define IDB_BK1                         131
#define IDB_BK1D                        132
#define IDB_BK2                         133
#define IDB_BK2D                        134
#define IDB_BK3                         135
#define IDB_BK3D                        136
#define IDB_SB                          137
#define IDS_EB                          149
#define IDS_EBM                         151
#define IDS_P2DEAD                      158
#define IDS_P2MDEAD                     159
#define IDS_P1DEAD                      160
#define IDS_P1MDEAD                     161
#define IDB_TITLE                       3000
#define IDB_SBP1                        3001
#define IDB_SBP2                        3002
#define IDB_SBCOM                       3003
#define IDB_FLOOR                       3004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        162
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
