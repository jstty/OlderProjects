////////////////////////////////////////////////////////////////////////
//	Program Name:	Controls.cpp
//	Programmer:		Joseph Sutton
//	Company:			Moggie Software
//	Corporation:	Willy Wong Ping Pong Inc.
//	Description:	Controls File
//	Date: 
////////////////////////////////////////////////////////////////////////
#include "E:\My Code\Young George VS Lost Island\YoungGeroge.h"
#include "Controls.h"

