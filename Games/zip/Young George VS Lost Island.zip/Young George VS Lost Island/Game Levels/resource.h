//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AlienLevels.rc
//
#define IDST_FILEERROR                  1
#define IDST_TITLE                      2
#define IDST_USE                        3
#define IDST_EXAMINE                    4
#define IDST_TALK                       5
#define IDST_OPEN                       6
#define IDST_CLOSE                      7
#define IDST_GET                        8
#define IDST_GIVE                       9
#define IDST_PUSH                       10
#define IDST_WITH                       11
#define IDST_TO                         12
#define IDST_KEY                        13
#define IDST_SODA                       14
#define IDST_ROBOARM                    15
#define IDST_APP                        16
#define IDST_CANDYBAR                   17
#define IDST_REMOTE                     18
#define IDST_ENVELOP                    19
#define IDST_SANTA                      20
#define IDST_STAKE                      21
#define IDST_STAMP                      22
#define IDST_VEGGY                      23
#define IDST_E_KEY                      24
#define IDST_E_SODA                     25
#define IDST_E_ROBOARM                  26
#define IDST_E_APP                      27
#define IDST_E_CANDYBAR                 28
#define IDST_E_REMOTE                   29
#define IDST_E_ENVELOP                  30
#define IDST_E_SANTA                    31
#define IDST_E_STAKE                    32
#define IDST_E_STAMP                    33
#define IDST_E_VEGGY                    34
#define IDST_T_MOON1                    35
#define IDST_MOON_L2                    35
#define IDST_T_MOON1a                   36
#define IDST_MOON_L2_1                  36
#define IDST_T_SELF1                    37
#define IDST_SELF_L2                    37
#define IDST_ERROR_L1                   38
#define IDST_ERROR_L2                   38
#define IDST_SELF_L3                    39
#define IDST_ERROR_L3                   40
#define IDST_MOON_L3                    41
#define IDST_SIGN_L3                    42
#define IDST_SELF_L4                    43
#define IDST_ERROR_L4                   44
#define IDST_MOON_L4                    45
#define IDST_OPEN_L4_1                  46
#define IDST_CLOSE_L4_1                 47
#define IDST_CLOSE_L4_2                 48
#define IDST_OPEN_L4_2                  49
#define IDST_PUSH_L4_1                  50
#define IDST_PUSH_L4_2                  51
#define IDS_MBOXB                       118
#define IDS_MBOXM                       119
#define IDB_LEVEL02                     120
#define IDB_LEVEL03                     121
#define IDB_LEVEL04                     122
#define IDB_MOON                        123
#define IDS_POSTB                       124
#define IDS_POSTM                       125
#define IDB_SIGN                        127
#define IDB_LEVEL05                     129
#define IDB_LADDER1                     130
#define IDS_STAKEB                      131
#define IDS_STAKEM                      132
#define IDB_LEVEL06                     133
#define IDB_LEVEL07                     134
#define IDB_TREE                        135
#define IDS_KEYB                        136
#define IDS_KEYM                        137
#define IDS_FDOOR1B                     138
#define IDS_FDOOR1M                     139
#define IDS_FDOOR2B                     140
#define IDS_FDOOR2M                     141
#define IDB_LEVEL08                     142
#define IDB_WINDOW1                     143
#define IDS_RDOORB                      144
#define IDS_RDOORM                      145
#define IDS_GEORGEB                     146
#define IDS_GEORGEM                     147
#define IDB_PIC1                        148
#define IDB_STAIRS                      149
#define IDB_TITLEBKG                    150
#define IDS_TITLEB                      151
#define IDS_TITLEM                      152
#define IDB_PATH_2                      153
#define IDW_END1                        159
#define IDW_END2                        160
#define IDB_PATH_3                      161
#define IDB_PATH_4                      162
#define IDB_PATH_5                      163
#define IDB_PATH_6                      164
#define IDB_PATH_7                      165
#define IDB_PATH_8                      166

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        167
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
