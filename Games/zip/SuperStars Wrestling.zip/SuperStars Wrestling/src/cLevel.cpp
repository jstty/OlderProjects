/* //////////////////////////////////////////////////////////////////////
 Program Name:  cLevel.cpp
 Programmer:    Joseph E. Sutton
 Start Date:    2006-06-16
 Updated:       
 Version:       1.00
 Description:
   Level Class Source File
   
////////////////////////////////////////////////////////////////////// */

#include "main.h"

cLevel::cLevel()
{
   m_display = NULL;
}

cLevel::~cLevel()
{
}

int cLevel::Init()
{
   return 0;
}

int cLevel::Exit()
{
   return 0;
}


int cLevel::Loop()
{
   return 0;
}

int cLevel::Draw()
{
   return 0;
}

int cLevel::Sound()
{
   return 0;
}

