//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Skull v2.rc
//
#define IDI_MAIN                        101
#define IDD_DEBUG                       110
#define IDD_DEBUG1                      111
#define IDB_TILE03_B                    174
#define IDB_TILE01                      175
#define IDB_TILE01_M                    176
#define IDB_TILE02_M                    177
#define IDB_TILE02_A                    178
#define IDB_TILE02_B                    179
#define IDB_TILE03_M                    180
#define IDB_TILE03_A                    181
#define IDB_SCREEN                      183
#define IDB_ARROW                       184
#define IDB_BOX_1                       185
#define IDB_BOX_1_S                     186
#define IDB_BOX_2                       187
#define IDB_BOX_2_S                     188
#define IDB_BOX_3                       189
#define IDB_BOX_3_S                     190
#define IDB_TILE_NUM1                   191
#define IDB_TILE_NUM2                   192
#define IDB_TILE_NUM3                   193
#define IDD_LOADLEVEL                   194
#define IDD_PROGRESS                    201
#define IDC_TREE                        1002
#define IDC_PROG                        1008
#define IDC_PROGRESS1                   1009
#define IDC_PROGRESS2                   1010
#define IDC_NAME                        1011
#define IDC_MAIN                        1012
#define IDC_LIST                        1262

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        208
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
