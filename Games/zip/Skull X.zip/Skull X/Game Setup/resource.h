//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Game Setup.rc
//
#define IDCANCEL2                       3
#define IDD_GAMESETUP_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_REF                         129
#define IDD_WEP                         131
#define IDD_PLAYER                      133
#define IDD_SETUPV2_DIALOG              134
#define IDD_DIALOG1                     135
#define IDC_RADIO1                      1000
#define IDC_MIDI                        1000
#define IDC_RADIO2                      1001
#define IDC_SNDFX                       1001
#define IDC_EDIT1                       1002
#define IDC_RADIO28                     1002
#define IDC_RADIO3                      1003
#define IDC_RADIO4                      1004
#define IDC_GAMESPEED                   1004
#define IDC_RADIO5                      1005
#define IDC_RADIO6                      1006
#define IDC_EDIT8                       1006
#define IDC_RADIO7                      1007
#define IDC_RESET                       1007
#define IDC_RADIO8                      1008
#define IDC_RADIO9                      1009
#define IDC_RADIO10                     1010
#define IDC_RADIO11                     1011
#define IDC_JOY1_STAT                   1011
#define IDC_EDIT2                       1012
#define IDC_RADIO18                     1012
#define IDC_JOY2_STAT                   1012
#define IDC_RADIO12                     1013
#define IDC_RES                         1013
#define IDC_RADIO13                     1014
#define IDC_RADIO19                     1014
#define IDC_EDIT3                       1015
#define IDC_RADIO16                     1015
#define IDC_RADIO14                     1016
#define IDC_EDIT5                       1016
#define IDC_RADIO15                     1017
#define IDC_EDIT6                       1017
#define IDC_EDIT4                       1018
#define IDC_RADIO17                     1018
#define IDC_RADIO24                     1018
#define IDC_BUTTON1                     1019
#define IDC_CHECK1                      1020
#define IDC_STRETCH2                    1020
#define IDC_CHECK2                      1021
#define IDC_BUTTON2                     1022
#define IDC_KEY_UP                      1022
#define IDC_CHECK3                      1023
#define IDC_KEY_DOWN                    1023
#define IDC_CHECK4                      1024
#define IDC_KEY_LEFT                    1024
#define IDC_EDIT7                       1025
#define IDC_KEY_RIGHT                   1025
#define IDC_RADIO27                     1026
#define IDC_KEY_B1                      1026
#define IDC_COMBO1                      1027
#define IDC_KEY_B2                      1027
#define IDC_KEY_B3                      1028
#define IDC_BUTTON3                     1029
#define IDC_BUTTON4                     1030
#define IDC_KEY_ESC                     1031
#define IDC_RADIO20                     1031
#define IDC_KEY_SETUP                   1032
#define IDC_RADIO21                     1032
#define IDC_RADIO22                     1033
#define IDC_RADIO23                     1034
#define IDC_JOY1_B1                     1035
#define IDC_JOY1_B2                     1036
#define IDC_LIST2                       1037
#define IDC_JOY1_P                      1038
#define IDC_JOY2_B1                     1039
#define IDC_RADIO29                     1039
#define IDC_JOY2_B2                     1040
#define IDC_RADIO30                     1040
#define IDC_JOY2_P                      1042
#define IDC_KEY_P                       1043
#define IDC_KEY_SETUP2                  1046
#define IDC_RADIO40                     1050
#define IDC_RADIO41                     1051
#define IDC_CHECK6                      1052
#define IDC_RADIO42                     1052
#define IDC_RADIO43                     1053
#define IDC_RADIO25                     1054
#define IDC_RADIO26                     1055
#define IDC_CHECK7                      1056
#define IDC_COMBO2                      1057
#define IDC_COMBO3                      1058
#define IDC_LIST1                       1059
#define IDC_BUTTON5                     1060
#define IDC_BUTTON6                     1061
#define IDC_BUTTON7                     1062
#define IDC_BUTTON8                     1063
#define IDC_BUTTON9                     1064

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1061
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
