////////////////////////////////////////////////////////////////////////
//	Program Name:	Game.cpp
//	Programmer:		Joseph E. Sutton
//	Company:			Moggie Software
//	Corporation:	Willy Wong Ping Pong Inc.
//	Description:	Game File
//	Date:					02/27/2000
//	Version:			1.00
////////////////////////////////////////////////////////////////////////

#include "..\Header Files\GameClass.h"


